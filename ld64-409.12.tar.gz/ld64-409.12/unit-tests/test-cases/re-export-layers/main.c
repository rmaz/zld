

extern void baz();
extern void bar();
extern void foo();


int main()
{
	baz();
	bar();
	foo();
	return 0;
}

