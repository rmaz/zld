extern int foo();
extern int mybar();

int main()
{
	foo();
	mybar();
	return 0;
}

