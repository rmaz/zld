
int bar(void)
{
  return 1;
}

__attribute__((weak))
void bar_weak()
{
}
