void foo() {}
int var = 9;
