
__attribute__((weak))
int myweak = 10;

