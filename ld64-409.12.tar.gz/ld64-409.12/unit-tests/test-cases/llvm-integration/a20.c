void foo() {}
void bar() {}
