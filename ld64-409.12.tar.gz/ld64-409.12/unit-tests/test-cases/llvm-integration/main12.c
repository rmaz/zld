#include "a12.h"
int main()
{
  e[0] = ZERO;
  foo();
  return e[0];
}
