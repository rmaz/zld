int X __attribute__((visibility("hidden"))) = 14;
