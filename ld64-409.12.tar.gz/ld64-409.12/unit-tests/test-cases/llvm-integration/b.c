int foo2() {
	return 21;
}
