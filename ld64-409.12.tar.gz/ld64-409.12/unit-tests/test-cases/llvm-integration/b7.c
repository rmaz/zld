extern int foo2(void);
extern int foo3(void);

int foo3(void)
{
  return foo2();
}
