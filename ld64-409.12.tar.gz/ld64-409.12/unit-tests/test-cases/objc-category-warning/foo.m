#include <Foundation/Foundation.h>

@interface Foo : NSObject
-(void) instance_method;
+(void) class_method;
@end


@implementation Foo
-(void) instance_method {}
+(void) class_method {}
@end

