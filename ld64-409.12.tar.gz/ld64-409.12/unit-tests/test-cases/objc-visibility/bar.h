
#include <Foundation/Foundation.h>

__attribute__((visibility("hidden")))
@interface Bar : NSData 
- (NSArray*) bar;
@end

