#include <Foundation/Foundation.h>


#include "bar.h"


@implementation Bar
- (NSArray*) bar
{
	return [NSArray array];
}
@end

