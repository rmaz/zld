
#include <Foundation/Foundation.h>


@interface Foo : NSObject
- (NSString*) foo;
@end

