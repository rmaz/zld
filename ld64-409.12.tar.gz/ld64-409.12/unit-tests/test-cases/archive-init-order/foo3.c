int foo3() { return 1; }

__attribute__((constructor))
void foo3_init() { }
