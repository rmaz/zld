extern int common_variable;

int
main(int argc, char **argv)
{
	return common_variable;
}
