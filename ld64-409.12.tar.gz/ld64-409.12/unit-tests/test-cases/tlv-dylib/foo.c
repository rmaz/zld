
// foo is an exported thread local variable
__thread int foo[1024];

// _bar is an exported regular variable
int bar = 5;

