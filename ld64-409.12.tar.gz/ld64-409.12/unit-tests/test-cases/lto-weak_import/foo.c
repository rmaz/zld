

void foo() {}
