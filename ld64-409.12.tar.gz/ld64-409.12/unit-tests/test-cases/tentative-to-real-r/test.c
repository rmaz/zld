
void foo() {}

int a;
int b;
int c;



int* pa = &a;
int* pb = &b;
int* pc = &c;

