
int baz()
{
	return 1;
}
