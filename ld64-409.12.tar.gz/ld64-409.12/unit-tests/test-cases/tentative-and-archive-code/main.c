
int foo;

int main()
{
	foo = 3;
	return 0;
}
