 const char* mystring = "hello";
