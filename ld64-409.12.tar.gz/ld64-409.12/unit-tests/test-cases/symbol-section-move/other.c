
static int mylocal()
{
  return 1;
}

void* otherget() { return mylocal; }


