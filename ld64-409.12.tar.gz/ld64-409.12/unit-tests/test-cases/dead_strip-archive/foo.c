

void foo() {}


int my_common;

