
void bar() { }

int baz()
{
	return -1;
}

