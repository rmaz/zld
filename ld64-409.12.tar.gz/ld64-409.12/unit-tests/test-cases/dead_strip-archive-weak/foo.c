
extern void good();

void foo() 
{
	good();
}

void loadme()
{
//	foo();
}

