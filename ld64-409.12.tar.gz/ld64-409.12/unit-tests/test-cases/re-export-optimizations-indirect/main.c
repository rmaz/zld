
extern void bar();

int main()
{
	bar();
	return 0;
}
