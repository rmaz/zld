extern int foo();
extern int bart();

int main()
{
	foo();
	bart();
	return 0;
}
