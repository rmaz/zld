
int barb(void)
{
	return 1;
}

int bart(void)
{
	return 0;
}
