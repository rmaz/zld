extern void bar();
extern int result;

int myresult = 1;

int mymain()
{
  bar();
  return result;
}

void mybar()
{

}

