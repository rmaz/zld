
int tent;

int bar() { return tent; }
