
int tent;

int baz() { return tent; }

