#include "bar.h"

@implementation Bar
- (void) test {
	bar2();
}
@end
