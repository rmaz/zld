
#include "foo.h"

@implementation Foo
- (void) test {
	foo2();
}
@end
