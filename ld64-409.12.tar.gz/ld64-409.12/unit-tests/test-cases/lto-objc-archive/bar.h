#include <Foundation/Foundation.h>

@interface Bar : NSObject
@end

extern void bar2();
