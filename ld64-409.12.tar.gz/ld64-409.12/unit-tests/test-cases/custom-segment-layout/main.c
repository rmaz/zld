
int x = 5;

int main()
{
	return 0;
}

