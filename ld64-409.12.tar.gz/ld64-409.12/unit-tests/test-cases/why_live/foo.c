
extern void bar();

void foo()
{
	bar();
}

void frob()
{
	bar();
}