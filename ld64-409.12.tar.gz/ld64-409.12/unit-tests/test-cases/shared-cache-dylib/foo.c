

int x;

int foo() { return x; }

