
extern void c2();

void a1(void)
{
	c2();
}

void a2(void)
{
}
