
extern void c1();

void b1(void)
{
	c1();
}
