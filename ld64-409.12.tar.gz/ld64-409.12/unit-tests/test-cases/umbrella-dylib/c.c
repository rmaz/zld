
extern void a2();

void c1(void)
{
	a2();
}

void c2(void)
{
}
