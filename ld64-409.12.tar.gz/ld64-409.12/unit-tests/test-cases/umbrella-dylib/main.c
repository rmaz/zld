extern void c1();
extern void a1();
int main()
{
  a1();
  c1();
  return 0;
}
