
int var;
int other_tent;

int main()
{
	var = 3;
	return 0;
}
